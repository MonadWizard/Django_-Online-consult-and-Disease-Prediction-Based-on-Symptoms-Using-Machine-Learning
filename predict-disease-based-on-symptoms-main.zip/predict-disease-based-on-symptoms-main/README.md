# predict-disease-based-on-symptoms


disease_model.py
Main Model of Disease,
After modifying dataset into a python dictionary-like, 
disease in a key and all symptoms related to that disease, to value as list

disease.py
List of all disease

symptoms.py
List if all symptoms

requirements.txt
need to install those required to run this disease_model.py

Dataset collect from a study published in Nature Communications, researchers XueZhong Zhou, et al., have constructed a human symptoms-disease network (HSDN)
link:https://www.nature.com/articles/ncomms5212


There disease_model.py can be use as module to predict disease based on symptoms.
It can use on Djnago Flask or any python based frameworks.


